<?php

namespace App\Classes;

class  UploadFile
{



    /*
     * @var string
     */
    public $upload_file;

    public $categorie;
}
